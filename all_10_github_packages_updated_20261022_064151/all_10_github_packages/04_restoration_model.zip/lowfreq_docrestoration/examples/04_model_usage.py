"""Model API usage with untrained weights."""
import torch
from docrestore.model import UNet

torch.set_num_threads(1)
model = UNet()
with torch.no_grad():
    output = model(torch.zeros(1, 1, 32, 40))
print({"output_shape": list(output.shape), "range": [float(output.min()), float(output.max())], "trained": False})
