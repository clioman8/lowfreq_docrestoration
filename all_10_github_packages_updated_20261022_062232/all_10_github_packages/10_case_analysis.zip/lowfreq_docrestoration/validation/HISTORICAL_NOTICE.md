Original validation/*.json objects are retained byte-for-byte and describe historical packaging/fixture checks, not updated thesis results. See latest/ for current merged-project checks.
