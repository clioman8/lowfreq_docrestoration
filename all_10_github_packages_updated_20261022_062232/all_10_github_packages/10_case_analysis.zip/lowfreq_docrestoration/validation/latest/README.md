These records describe the full merged project, not separate re-testing of this isolated ZIP. They verify software/numerics and do not contain final restoration-performance findings.
