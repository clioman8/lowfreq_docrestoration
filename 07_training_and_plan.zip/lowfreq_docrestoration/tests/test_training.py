"""Small numerical integration checks, independent of OCR assets and datasets."""

import tempfile
import unittest
from pathlib import Path

import numpy as np

try:
    import torch
except ImportError:
    torch = None

if torch is not None:
    from docrestore.model import UNet
    from docrestore.train import seed_everything, validation_score
    from docrestore.operators import forward_torch
    from docrestore.losses import (build_fourier_basis, data_loss,
                                   full_consistency_loss,
                                   subspace_consistency_loss, ssim_torch)


@unittest.skipIf(torch is None, "PyTorch not installed")
class TrainingIntegrationTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)

    def _one_step(self, group, device="cpu"):
        seed_everything(17)
        model = UNet((4, 8, 12, 16)).to(device)
        initial = {name: value.detach().cpu().clone()
                   for name, value in model.state_dict().items()}
        optimizer = torch.optim.Adam(model.parameters(), lr=2e-4)
        generator = torch.Generator().manual_seed(719)
        clean = torch.rand((2, 1, 32, 40), generator=generator).to(device)
        eta = {"kappa": torch.tensor([.2, .8], device=device),
               "alpha": torch.tensor([.1, .3], device=device), "T": .7}
        with torch.no_grad():
            observed = forward_torch(clean, **eta, n_steps=3)
        pred = model(observed)
        reconstruction = data_loss(pred, clean)
        residual = forward_torch(pred, **eta, n_steps=3) - observed
        full = full_consistency_loss(residual)
        Q = torch.tensor(build_fourier_basis(32, 40, 12), dtype=pred.dtype, device=device)
        sub = subspace_consistency_loss(residual, Q)
        # These are exactly the output-gradient diagnostics recorded by fit().
        for component in (reconstruction, full, sub):
            gradient = torch.autograd.grad(component, pred, retain_graph=True)[0]
            self.assertTrue(torch.isfinite(gradient).all())
        total = reconstruction if group == "A" else reconstruction + .1 * (
            full if group == "B" else sub)
        optimizer.zero_grad(set_to_none=True)
        total.backward()
        self.assertTrue(torch.isfinite(total))
        gradients = [p.grad for p in model.parameters() if p.grad is not None]
        self.assertTrue(gradients)
        self.assertTrue(all(torch.isfinite(g).all() for g in gradients))
        optimizer.step()
        changed = any(not torch.equal(value.detach().cpu(), initial[name])
                      for name, value in model.state_dict().items())
        self.assertTrue(changed)
        return model, initial, observed

    def test_float32_model_operator_losses_all_groups(self):
        initial_reference = observed_reference = None
        for group in ("A", "B", "C"):
            model, initial, observed = self._one_step(group)
            if initial_reference is None:
                initial_reference, observed_reference = initial, observed
            else:
                for key, value in initial.items():
                    self.assertTrue(torch.equal(value, initial_reference[key]))
                self.assertTrue(torch.equal(observed, observed_reference))

    def test_validation_selection_is_corpus_weighted_and_excludes_s0(self):
        rows = [{"severity_id": "S0", "gt_chars": 100, "edit_distance": 999},
                {"severity_id": "S1", "gt_chars": 10, "edit_distance": 1},
                {"severity_id": "S1", "gt_chars": 90, "edit_distance": 3},
                {"severity_id": "S2", "gt_chars": 100, "edit_distance": 3}]
        maximum, mean = validation_score(rows, ["S1", "S2"])
        self.assertAlmostEqual(maximum, .04)
        self.assertAlmostEqual(mean, .035)
        # Lexicographic max-first, mean-second selection used in fit().
        self.assertLess((.04, .035), (.05, .02))
        self.assertLess((.04, .035), (.04, .04))
        with self.assertRaises(ValueError):
            validation_score(rows, ["S1", "S3"])

    def test_checkpoint_weights_only_roundtrip(self):
        model, _, observed = self._one_step("C")
        model.eval()
        with torch.no_grad():
            before = model(observed)
        checkpoint = {"model_state": model.state_dict(),
                      "config": {"model": {"channels": [4, 8, 12, 16]}},
                      "metadata": {"group": "C", "seed": 17},
                      "step": 1, "validation_score": [.3, .2]}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "checkpoint.pt"
            torch.save(checkpoint, path)
            restored = torch.load(path, map_location="cpu", weights_only=True)
        replica = UNet((4, 8, 12, 16))
        replica.load_state_dict(restored["model_state"])
        replica.eval()
        with torch.no_grad():
            after = replica(observed)
        torch.testing.assert_close(before, after, atol=0, rtol=0)

    @unittest.skipUnless(torch is not None and torch.cuda.is_available(),
                         "CUDA hardware unavailable; CPU checks do not certify GPU execution")
    def test_strict_deterministic_cuda_backward(self):
        self._one_step("C", "cuda")


if __name__ == "__main__":
    unittest.main()
