"""Operator API usage on a synthetic array; no thesis performance result."""
import numpy as np
import torch
from docrestore.operators import forward_numpy, forward_torch

u = np.ones((16, 20), dtype=np.float32)
u[5:11, 8:12] = 0.0
y = forward_numpy(u, kappa=0.4, alpha=0.04, T=1.0, n_steps=8)
x = torch.tensor(u[None, None], requires_grad=True)
yt = forward_torch(x, kappa=0.4, alpha=0.04, T=1.0, n_steps=8)
yt.sum().backward()
print({"output_shape": list(y.shape), "numpy_torch_max_abs_difference": float(np.max(np.abs(y - yt.detach().numpy()[0, 0]))), "gradient_finite": bool(torch.isfinite(x.grad).all())})
